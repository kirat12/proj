﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Rasp
{
    public partial class SmartTrash : Form
    {
        public SmartTrash()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }
        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (q1c2.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q1c1.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q1c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }

        }

        private void q1c1_CheckedChanged(object sender, EventArgs e)
        {
            if (q1c1.Checked == true)
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (q2c2.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q2c1.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q2c3.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (q3c2.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q3c1.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q3c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (q4c2.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q4c1.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q4c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (q5c2.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q5c1.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q5c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (q6c2.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q6c1.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q6c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (q7c2.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q7c1.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q7c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (q8c2.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q8c1.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q8c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (q9c2.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q9c1.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q9c3.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (q10c2.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q10c1.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q10c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (q11c2.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q11c1.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q11c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (q12c2.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q12c1.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q12c3.Checked == true)
            {
                MessageBox.Show("Yes, This type of waste are not acceted by Toronto Waste Management");
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (q13c2.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q13c1.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q13c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (q15c2.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q15c1.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q15c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (q14c2.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q14c1.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q14c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (q16c2.Checked == true)
            {
                MessageBox.Show("You are Right!");
            }
            else if (q16c1.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
            else if (q16c3.Checked == true)
            {
                MessageBox.Show("You are Wrong");
            }
        }
    }
}
