﻿namespace Final_Rasp
{
    partial class SmartTrash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SmartTrash));
            this.book = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.q1c1 = new System.Windows.Forms.CheckBox();
            this.q1c2 = new System.Windows.Forms.CheckBox();
            this.q1c3 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.q2c1 = new System.Windows.Forms.CheckBox();
            this.q2c2 = new System.Windows.Forms.CheckBox();
            this.q2c3 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.q3c1 = new System.Windows.Forms.CheckBox();
            this.q3c2 = new System.Windows.Forms.CheckBox();
            this.q3c3 = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.q4c1 = new System.Windows.Forms.CheckBox();
            this.q4c2 = new System.Windows.Forms.CheckBox();
            this.q4c3 = new System.Windows.Forms.CheckBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.q5c1 = new System.Windows.Forms.CheckBox();
            this.q5c2 = new System.Windows.Forms.CheckBox();
            this.q5c3 = new System.Windows.Forms.CheckBox();
            this.button5 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.q6c1 = new System.Windows.Forms.CheckBox();
            this.q6c2 = new System.Windows.Forms.CheckBox();
            this.q6c3 = new System.Windows.Forms.CheckBox();
            this.q7c1 = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.q7c2 = new System.Windows.Forms.CheckBox();
            this.q7c3 = new System.Windows.Forms.CheckBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.q8c1 = new System.Windows.Forms.CheckBox();
            this.q8c2 = new System.Windows.Forms.CheckBox();
            this.q8c3 = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.q9c1 = new System.Windows.Forms.CheckBox();
            this.q9c2 = new System.Windows.Forms.CheckBox();
            this.q9c3 = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.q10c1 = new System.Windows.Forms.CheckBox();
            this.q10c2 = new System.Windows.Forms.CheckBox();
            this.q10c3 = new System.Windows.Forms.CheckBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.q11c1 = new System.Windows.Forms.CheckBox();
            this.q11c2 = new System.Windows.Forms.CheckBox();
            this.q11c3 = new System.Windows.Forms.CheckBox();
            this.button11 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.q12c1 = new System.Windows.Forms.CheckBox();
            this.q13c1 = new System.Windows.Forms.CheckBox();
            this.q12c2 = new System.Windows.Forms.CheckBox();
            this.q13c2 = new System.Windows.Forms.CheckBox();
            this.q12c3 = new System.Windows.Forms.CheckBox();
            this.q13c3 = new System.Windows.Forms.CheckBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.q14c1 = new System.Windows.Forms.CheckBox();
            this.q14c2 = new System.Windows.Forms.CheckBox();
            this.q14c3 = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.q15c1 = new System.Windows.Forms.CheckBox();
            this.q15c2 = new System.Windows.Forms.CheckBox();
            this.q15c3 = new System.Windows.Forms.CheckBox();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.q16c1 = new System.Windows.Forms.CheckBox();
            this.q16c2 = new System.Windows.Forms.CheckBox();
            this.q16c3 = new System.Windows.Forms.CheckBox();
            this.button16 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // book
            // 
            this.book.AcceptsReturn = true;
            this.book.AcceptsTab = true;
            this.book.AllowDrop = true;
            this.book.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.book.Location = new System.Drawing.Point(12, 12);
            this.book.MaxLength = 3276788;
            this.book.Multiline = true;
            this.book.Name = "book";
            this.book.ReadOnly = true;
            this.book.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.book.Size = new System.Drawing.Size(344, 546);
            this.book.TabIndex = 0;
            this.book.Text = resources.GetString("book.Text");
            this.book.WordWrap = false;
            this.book.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(367, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(324, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "LETS SEE HOW MUCH YOU KNOW ABOUT TRASH";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Monotype Corsiva", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox1.Location = new System.Drawing.Point(374, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(306, 21);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "SOME OF THE DAILY USE THINGS.....";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(364, 236);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "1. Tim Horton Coffee cup";
            // 
            // q1c1
            // 
            this.q1c1.AutoSize = true;
            this.q1c1.Location = new System.Drawing.Point(374, 251);
            this.q1c1.Name = "q1c1";
            this.q1c1.Size = new System.Drawing.Size(65, 17);
            this.q1c1.TabIndex = 8;
            this.q1c1.Text = "Blue Bin";
            this.q1c1.UseVisualStyleBackColor = true;
            this.q1c1.CheckedChanged += new System.EventHandler(this.q1c1_CheckedChanged);
            // 
            // q1c2
            // 
            this.q1c2.AutoSize = true;
            this.q1c2.Location = new System.Drawing.Point(446, 252);
            this.q1c2.Name = "q1c2";
            this.q1c2.Size = new System.Drawing.Size(71, 17);
            this.q1c2.TabIndex = 9;
            this.q1c2.Text = "Black Bin";
            this.q1c2.UseVisualStyleBackColor = true;
            // 
            // q1c3
            // 
            this.q1c3.AutoSize = true;
            this.q1c3.Location = new System.Drawing.Point(523, 251);
            this.q1c3.Name = "q1c3";
            this.q1c3.Size = new System.Drawing.Size(73, 17);
            this.q1c3.TabIndex = 10;
            this.q1c3.Text = "Green Bin";
            this.q1c3.UseVisualStyleBackColor = true;
            this.q1c3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(602, 235);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(52, 33);
            this.button1.TabIndex = 11;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(362, 275);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "2. Paper napkin";
            // 
            // q2c1
            // 
            this.q2c1.AutoSize = true;
            this.q2c1.Location = new System.Drawing.Point(374, 292);
            this.q2c1.Name = "q2c1";
            this.q2c1.Size = new System.Drawing.Size(65, 17);
            this.q2c1.TabIndex = 13;
            this.q2c1.Text = "Blue Bin";
            this.q2c1.UseVisualStyleBackColor = true;
            // 
            // q2c2
            // 
            this.q2c2.AutoSize = true;
            this.q2c2.Location = new System.Drawing.Point(446, 292);
            this.q2c2.Name = "q2c2";
            this.q2c2.Size = new System.Drawing.Size(71, 17);
            this.q2c2.TabIndex = 14;
            this.q2c2.Text = "Black Bin";
            this.q2c2.UseVisualStyleBackColor = true;
            // 
            // q2c3
            // 
            this.q2c3.AutoSize = true;
            this.q2c3.Location = new System.Drawing.Point(523, 292);
            this.q2c3.Name = "q2c3";
            this.q2c3.Size = new System.Drawing.Size(73, 17);
            this.q2c3.TabIndex = 15;
            this.q2c3.Text = "Green Bin";
            this.q2c3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(602, 275);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(52, 34);
            this.button2.TabIndex = 16;
            this.button2.Text = "Submit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(362, 317);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "3. Plastic water bottle";
            // 
            // q3c1
            // 
            this.q3c1.AutoSize = true;
            this.q3c1.Location = new System.Drawing.Point(374, 333);
            this.q3c1.Name = "q3c1";
            this.q3c1.Size = new System.Drawing.Size(65, 17);
            this.q3c1.TabIndex = 18;
            this.q3c1.Text = "Blue Bin";
            this.q3c1.UseVisualStyleBackColor = true;
            // 
            // q3c2
            // 
            this.q3c2.AutoSize = true;
            this.q3c2.Location = new System.Drawing.Point(446, 333);
            this.q3c2.Name = "q3c2";
            this.q3c2.Size = new System.Drawing.Size(71, 17);
            this.q3c2.TabIndex = 19;
            this.q3c2.Text = "Black Bin";
            this.q3c2.UseVisualStyleBackColor = true;
            // 
            // q3c3
            // 
            this.q3c3.AutoSize = true;
            this.q3c3.Location = new System.Drawing.Point(523, 333);
            this.q3c3.Name = "q3c3";
            this.q3c3.Size = new System.Drawing.Size(73, 17);
            this.q3c3.TabIndex = 20;
            this.q3c3.Text = "Green Bin";
            this.q3c3.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(362, 353);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "4. Bubble wrap";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(602, 317);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(52, 33);
            this.button3.TabIndex = 22;
            this.button3.Text = "Submit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // q4c1
            // 
            this.q4c1.AutoSize = true;
            this.q4c1.Location = new System.Drawing.Point(374, 370);
            this.q4c1.Name = "q4c1";
            this.q4c1.Size = new System.Drawing.Size(65, 17);
            this.q4c1.TabIndex = 23;
            this.q4c1.Text = "Blue Bin";
            this.q4c1.UseVisualStyleBackColor = true;
            // 
            // q4c2
            // 
            this.q4c2.AutoSize = true;
            this.q4c2.Location = new System.Drawing.Point(446, 370);
            this.q4c2.Name = "q4c2";
            this.q4c2.Size = new System.Drawing.Size(71, 17);
            this.q4c2.TabIndex = 24;
            this.q4c2.Text = "Black Bin";
            this.q4c2.UseVisualStyleBackColor = true;
            // 
            // q4c3
            // 
            this.q4c3.AutoSize = true;
            this.q4c3.Location = new System.Drawing.Point(523, 370);
            this.q4c3.Name = "q4c3";
            this.q4c3.Size = new System.Drawing.Size(73, 17);
            this.q4c3.TabIndex = 25;
            this.q4c3.Text = "Green Bin";
            this.q4c3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(602, 356);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(52, 31);
            this.button4.TabIndex = 26;
            this.button4.Text = "Submit";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(362, 394);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = "5. Broken Drinking glass";
            // 
            // q5c1
            // 
            this.q5c1.AutoSize = true;
            this.q5c1.Location = new System.Drawing.Point(374, 410);
            this.q5c1.Name = "q5c1";
            this.q5c1.Size = new System.Drawing.Size(65, 17);
            this.q5c1.TabIndex = 28;
            this.q5c1.Text = "Blue Bin";
            this.q5c1.UseVisualStyleBackColor = true;
            // 
            // q5c2
            // 
            this.q5c2.AutoSize = true;
            this.q5c2.Location = new System.Drawing.Point(446, 410);
            this.q5c2.Name = "q5c2";
            this.q5c2.Size = new System.Drawing.Size(72, 17);
            this.q5c2.TabIndex = 29;
            this.q5c2.Text = "Black BIn";
            this.q5c2.UseVisualStyleBackColor = true;
            // 
            // q5c3
            // 
            this.q5c3.AutoSize = true;
            this.q5c3.Location = new System.Drawing.Point(523, 410);
            this.q5c3.Name = "q5c3";
            this.q5c3.Size = new System.Drawing.Size(73, 17);
            this.q5c3.TabIndex = 30;
            this.q5c3.Text = "Green Bin";
            this.q5c3.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(602, 394);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(52, 33);
            this.button5.TabIndex = 31;
            this.button5.Text = "Submit";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(374, 39);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(306, 70);
            this.pictureBox1.TabIndex = 32;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(362, 434);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(139, 13);
            this.label7.TabIndex = 33;
            this.label7.Text = "6. Polyethylene Plastic bags";
            // 
            // q6c1
            // 
            this.q6c1.AutoSize = true;
            this.q6c1.Location = new System.Drawing.Point(374, 451);
            this.q6c1.Name = "q6c1";
            this.q6c1.Size = new System.Drawing.Size(65, 17);
            this.q6c1.TabIndex = 34;
            this.q6c1.Text = "Blue Bin";
            this.q6c1.UseVisualStyleBackColor = true;
            // 
            // q6c2
            // 
            this.q6c2.AutoSize = true;
            this.q6c2.Location = new System.Drawing.Point(446, 451);
            this.q6c2.Name = "q6c2";
            this.q6c2.Size = new System.Drawing.Size(71, 17);
            this.q6c2.TabIndex = 35;
            this.q6c2.Text = "Black Bin";
            this.q6c2.UseVisualStyleBackColor = true;
            // 
            // q6c3
            // 
            this.q6c3.AutoSize = true;
            this.q6c3.Location = new System.Drawing.Point(523, 451);
            this.q6c3.Name = "q6c3";
            this.q6c3.Size = new System.Drawing.Size(73, 17);
            this.q6c3.TabIndex = 36;
            this.q6c3.Text = "Green Bin";
            this.q6c3.UseVisualStyleBackColor = true;
            // 
            // q7c1
            // 
            this.q7c1.AutoSize = true;
            this.q7c1.Location = new System.Drawing.Point(374, 487);
            this.q7c1.Name = "q7c1";
            this.q7c1.Size = new System.Drawing.Size(65, 17);
            this.q7c1.TabIndex = 37;
            this.q7c1.Text = "Blue Bin";
            this.q7c1.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(362, 471);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 13);
            this.label8.TabIndex = 38;
            this.label8.Text = "7. Cardboards";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(362, 507);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 13);
            this.label9.TabIndex = 39;
            this.label9.Text = "8. Beer Can";
            // 
            // q7c2
            // 
            this.q7c2.AutoSize = true;
            this.q7c2.Location = new System.Drawing.Point(446, 487);
            this.q7c2.Name = "q7c2";
            this.q7c2.Size = new System.Drawing.Size(71, 17);
            this.q7c2.TabIndex = 40;
            this.q7c2.Text = "Black Bin";
            this.q7c2.UseVisualStyleBackColor = true;
            // 
            // q7c3
            // 
            this.q7c3.AutoSize = true;
            this.q7c3.Location = new System.Drawing.Point(523, 487);
            this.q7c3.Name = "q7c3";
            this.q7c3.Size = new System.Drawing.Size(73, 17);
            this.q7c3.TabIndex = 41;
            this.q7c3.Text = "Green Bin";
            this.q7c3.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(602, 434);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(52, 34);
            this.button6.TabIndex = 42;
            this.button6.Text = "Submit";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(602, 475);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(52, 29);
            this.button7.TabIndex = 43;
            this.button7.Text = "Submit";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // q8c1
            // 
            this.q8c1.AutoSize = true;
            this.q8c1.Location = new System.Drawing.Point(374, 523);
            this.q8c1.Name = "q8c1";
            this.q8c1.Size = new System.Drawing.Size(65, 17);
            this.q8c1.TabIndex = 44;
            this.q8c1.Text = "Blue Bin";
            this.q8c1.UseVisualStyleBackColor = true;
            // 
            // q8c2
            // 
            this.q8c2.AutoSize = true;
            this.q8c2.Location = new System.Drawing.Point(446, 523);
            this.q8c2.Name = "q8c2";
            this.q8c2.Size = new System.Drawing.Size(71, 17);
            this.q8c2.TabIndex = 45;
            this.q8c2.Text = "Black Bin";
            this.q8c2.UseVisualStyleBackColor = true;
            // 
            // q8c3
            // 
            this.q8c3.AutoSize = true;
            this.q8c3.Location = new System.Drawing.Point(523, 523);
            this.q8c3.Name = "q8c3";
            this.q8c3.Size = new System.Drawing.Size(73, 17);
            this.q8c3.TabIndex = 46;
            this.q8c3.Text = "Green Bin";
            this.q8c3.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(364, 546);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 13);
            this.label10.TabIndex = 47;
            this.label10.Text = "9. Vegetables";
            // 
            // q9c1
            // 
            this.q9c1.AutoSize = true;
            this.q9c1.Location = new System.Drawing.Point(374, 560);
            this.q9c1.Name = "q9c1";
            this.q9c1.Size = new System.Drawing.Size(65, 17);
            this.q9c1.TabIndex = 48;
            this.q9c1.Text = "Blue Bin";
            this.q9c1.UseVisualStyleBackColor = true;
            // 
            // q9c2
            // 
            this.q9c2.AutoSize = true;
            this.q9c2.Location = new System.Drawing.Point(446, 560);
            this.q9c2.Name = "q9c2";
            this.q9c2.Size = new System.Drawing.Size(71, 17);
            this.q9c2.TabIndex = 49;
            this.q9c2.Text = "Black Bin";
            this.q9c2.UseVisualStyleBackColor = true;
            // 
            // q9c3
            // 
            this.q9c3.AutoSize = true;
            this.q9c3.Location = new System.Drawing.Point(523, 560);
            this.q9c3.Name = "q9c3";
            this.q9c3.Size = new System.Drawing.Size(73, 17);
            this.q9c3.TabIndex = 50;
            this.q9c3.Text = "Green Bin";
            this.q9c3.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(362, 583);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 13);
            this.label11.TabIndex = 51;
            this.label11.Text = "10. Coffee Capsules";
            // 
            // q10c1
            // 
            this.q10c1.AutoSize = true;
            this.q10c1.Location = new System.Drawing.Point(374, 599);
            this.q10c1.Name = "q10c1";
            this.q10c1.Size = new System.Drawing.Size(65, 17);
            this.q10c1.TabIndex = 52;
            this.q10c1.Text = "Blue Bin";
            this.q10c1.UseVisualStyleBackColor = true;
            // 
            // q10c2
            // 
            this.q10c2.AutoSize = true;
            this.q10c2.Location = new System.Drawing.Point(446, 599);
            this.q10c2.Name = "q10c2";
            this.q10c2.Size = new System.Drawing.Size(71, 17);
            this.q10c2.TabIndex = 53;
            this.q10c2.Text = "Black Bin";
            this.q10c2.UseVisualStyleBackColor = true;
            // 
            // q10c3
            // 
            this.q10c3.AutoSize = true;
            this.q10c3.Location = new System.Drawing.Point(523, 599);
            this.q10c3.Name = "q10c3";
            this.q10c3.Size = new System.Drawing.Size(73, 17);
            this.q10c3.TabIndex = 54;
            this.q10c3.Text = "Green Bin";
            this.q10c3.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(602, 510);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(52, 30);
            this.button8.TabIndex = 55;
            this.button8.Text = "Submit";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(602, 546);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(52, 30);
            this.button9.TabIndex = 56;
            this.button9.Text = "Submit";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(602, 584);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(52, 32);
            this.button10.TabIndex = 57;
            this.button10.Text = "Submit";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(362, 619);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 13);
            this.label12.TabIndex = 58;
            this.label12.Text = "11. Foam";
            // 
            // q11c1
            // 
            this.q11c1.AutoSize = true;
            this.q11c1.Location = new System.Drawing.Point(374, 636);
            this.q11c1.Name = "q11c1";
            this.q11c1.Size = new System.Drawing.Size(65, 17);
            this.q11c1.TabIndex = 59;
            this.q11c1.Text = "Blue Bin";
            this.q11c1.UseVisualStyleBackColor = true;
            // 
            // q11c2
            // 
            this.q11c2.AutoSize = true;
            this.q11c2.Location = new System.Drawing.Point(446, 636);
            this.q11c2.Name = "q11c2";
            this.q11c2.Size = new System.Drawing.Size(74, 17);
            this.q11c2.TabIndex = 60;
            this.q11c2.Text = "Black Box";
            this.q11c2.UseVisualStyleBackColor = true;
            // 
            // q11c3
            // 
            this.q11c3.AutoSize = true;
            this.q11c3.Location = new System.Drawing.Point(523, 636);
            this.q11c3.Name = "q11c3";
            this.q11c3.Size = new System.Drawing.Size(76, 17);
            this.q11c3.TabIndex = 61;
            this.q11c3.Text = "Green Box";
            this.q11c3.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(602, 623);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(52, 30);
            this.button11.TabIndex = 62;
            this.button11.Text = "Submit";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(364, 656);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 13);
            this.label13.TabIndex = 63;
            this.label13.Text = "12. Cement Powder";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(365, 690);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 13);
            this.label14.TabIndex = 64;
            this.label14.Text = "13. Eye Glasses";
            // 
            // q12c1
            // 
            this.q12c1.AutoSize = true;
            this.q12c1.Location = new System.Drawing.Point(531, 672);
            this.q12c1.Name = "q12c1";
            this.q12c1.Size = new System.Drawing.Size(65, 17);
            this.q12c1.TabIndex = 65;
            this.q12c1.Text = "Blue Bin";
            this.q12c1.UseVisualStyleBackColor = true;
            // 
            // q13c1
            // 
            this.q13c1.AutoSize = true;
            this.q13c1.Location = new System.Drawing.Point(374, 706);
            this.q13c1.Name = "q13c1";
            this.q13c1.Size = new System.Drawing.Size(65, 17);
            this.q13c1.TabIndex = 66;
            this.q13c1.Text = "Blue Bin";
            this.q13c1.UseVisualStyleBackColor = true;
            // 
            // q12c2
            // 
            this.q12c2.AutoSize = true;
            this.q12c2.Location = new System.Drawing.Point(460, 672);
            this.q12c2.Name = "q12c2";
            this.q12c2.Size = new System.Drawing.Size(74, 17);
            this.q12c2.TabIndex = 67;
            this.q12c2.Text = "Black Box";
            this.q12c2.UseVisualStyleBackColor = true;
            // 
            // q13c2
            // 
            this.q13c2.AutoSize = true;
            this.q13c2.Location = new System.Drawing.Point(446, 706);
            this.q13c2.Name = "q13c2";
            this.q13c2.Size = new System.Drawing.Size(74, 17);
            this.q13c2.TabIndex = 68;
            this.q13c2.Text = "Black Box";
            this.q13c2.UseVisualStyleBackColor = true;
            // 
            // q12c3
            // 
            this.q12c3.AutoSize = true;
            this.q12c3.Location = new System.Drawing.Point(365, 672);
            this.q12c3.Name = "q12c3";
            this.q12c3.Size = new System.Drawing.Size(89, 17);
            this.q12c3.TabIndex = 69;
            this.q12c3.Text = "NotAccepted";
            this.q12c3.UseVisualStyleBackColor = true;
            // 
            // q13c3
            // 
            this.q13c3.AutoSize = true;
            this.q13c3.Location = new System.Drawing.Point(523, 706);
            this.q13c3.Name = "q13c3";
            this.q13c3.Size = new System.Drawing.Size(76, 17);
            this.q13c3.TabIndex = 70;
            this.q13c3.Text = "Green Box";
            this.q13c3.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(602, 659);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(52, 30);
            this.button12.TabIndex = 71;
            this.button12.Text = "Submit";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(602, 695);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(52, 28);
            this.button13.TabIndex = 72;
            this.button13.Text = "Submit";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(362, 127);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(139, 13);
            this.label15.TabIndex = 73;
            this.label15.Text = "14. Electronic Greeting card";
            // 
            // q14c1
            // 
            this.q14c1.AutoSize = true;
            this.q14c1.Location = new System.Drawing.Point(374, 143);
            this.q14c1.Name = "q14c1";
            this.q14c1.Size = new System.Drawing.Size(65, 17);
            this.q14c1.TabIndex = 74;
            this.q14c1.Text = "Blue Bin";
            this.q14c1.UseVisualStyleBackColor = true;
            // 
            // q14c2
            // 
            this.q14c2.AutoSize = true;
            this.q14c2.Location = new System.Drawing.Point(446, 143);
            this.q14c2.Name = "q14c2";
            this.q14c2.Size = new System.Drawing.Size(74, 17);
            this.q14c2.TabIndex = 75;
            this.q14c2.Text = "Black Box";
            this.q14c2.UseVisualStyleBackColor = true;
            // 
            // q14c3
            // 
            this.q14c3.AutoSize = true;
            this.q14c3.Location = new System.Drawing.Point(523, 143);
            this.q14c3.Name = "q14c3";
            this.q14c3.Size = new System.Drawing.Size(73, 17);
            this.q14c3.TabIndex = 76;
            this.q14c3.Text = "Green Bin";
            this.q14c3.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(362, 163);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 13);
            this.label16.TabIndex = 78;
            this.label16.Text = "15. Clothes";
            // 
            // q15c1
            // 
            this.q15c1.AutoSize = true;
            this.q15c1.Location = new System.Drawing.Point(374, 180);
            this.q15c1.Name = "q15c1";
            this.q15c1.Size = new System.Drawing.Size(65, 17);
            this.q15c1.TabIndex = 79;
            this.q15c1.Text = "Blue Bin";
            this.q15c1.UseVisualStyleBackColor = true;
            // 
            // q15c2
            // 
            this.q15c2.AutoSize = true;
            this.q15c2.Location = new System.Drawing.Point(444, 180);
            this.q15c2.Name = "q15c2";
            this.q15c2.Size = new System.Drawing.Size(74, 17);
            this.q15c2.TabIndex = 80;
            this.q15c2.Text = "Black Box";
            this.q15c2.UseVisualStyleBackColor = true;
            // 
            // q15c3
            // 
            this.q15c3.AutoSize = true;
            this.q15c3.Location = new System.Drawing.Point(523, 180);
            this.q15c3.Name = "q15c3";
            this.q15c3.Size = new System.Drawing.Size(73, 17);
            this.q15c3.TabIndex = 81;
            this.q15c3.Text = "Green Bin";
            this.q15c3.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(602, 168);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(52, 26);
            this.button15.TabIndex = 82;
            this.button15.Text = "Submit";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(602, 127);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(52, 30);
            this.button14.TabIndex = 83;
            this.button14.Text = "Submit";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(362, 200);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(109, 13);
            this.label17.TabIndex = 84;
            this.label17.Text = "16. TV remote control";
            // 
            // q16c1
            // 
            this.q16c1.AutoSize = true;
            this.q16c1.Location = new System.Drawing.Point(371, 214);
            this.q16c1.Name = "q16c1";
            this.q16c1.Size = new System.Drawing.Size(65, 17);
            this.q16c1.TabIndex = 85;
            this.q16c1.Text = "Blue Bin";
            this.q16c1.UseVisualStyleBackColor = true;
            // 
            // q16c2
            // 
            this.q16c2.AutoSize = true;
            this.q16c2.Location = new System.Drawing.Point(446, 216);
            this.q16c2.Name = "q16c2";
            this.q16c2.Size = new System.Drawing.Size(71, 17);
            this.q16c2.TabIndex = 86;
            this.q16c2.Text = "Black Bin";
            this.q16c2.UseVisualStyleBackColor = true;
            // 
            // q16c3
            // 
            this.q16c3.AutoSize = true;
            this.q16c3.Location = new System.Drawing.Point(523, 216);
            this.q16c3.Name = "q16c3";
            this.q16c3.Size = new System.Drawing.Size(73, 17);
            this.q16c3.TabIndex = 87;
            this.q16c3.Text = "Green Bin";
            this.q16c3.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(602, 200);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(52, 30);
            this.button16.TabIndex = 88;
            this.button16.Text = "Submit";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // SmartTrash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(703, 741);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.q16c3);
            this.Controls.Add(this.q16c2);
            this.Controls.Add(this.q16c1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.q15c3);
            this.Controls.Add(this.q15c2);
            this.Controls.Add(this.q15c1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.q14c3);
            this.Controls.Add(this.q14c2);
            this.Controls.Add(this.q14c1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.q13c3);
            this.Controls.Add(this.q12c3);
            this.Controls.Add(this.q13c2);
            this.Controls.Add(this.q12c2);
            this.Controls.Add(this.q13c1);
            this.Controls.Add(this.q12c1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.q11c3);
            this.Controls.Add(this.q11c2);
            this.Controls.Add(this.q11c1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.q10c3);
            this.Controls.Add(this.q10c2);
            this.Controls.Add(this.q10c1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.q9c3);
            this.Controls.Add(this.q9c2);
            this.Controls.Add(this.q9c1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.q8c3);
            this.Controls.Add(this.q8c2);
            this.Controls.Add(this.q8c1);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.q7c3);
            this.Controls.Add(this.q7c2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.q7c1);
            this.Controls.Add(this.q6c3);
            this.Controls.Add(this.q6c2);
            this.Controls.Add(this.q6c1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.q5c3);
            this.Controls.Add(this.q5c2);
            this.Controls.Add(this.q5c1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.q4c3);
            this.Controls.Add(this.q4c2);
            this.Controls.Add(this.q4c1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.q3c3);
            this.Controls.Add(this.q3c2);
            this.Controls.Add(this.q3c1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.q2c3);
            this.Controls.Add(this.q2c2);
            this.Controls.Add(this.q2c1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.q1c3);
            this.Controls.Add(this.q1c2);
            this.Controls.Add(this.q1c1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.book);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SmartTrash";
            this.Text = "Welcome to Smart Trash Guidelines";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox book;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox q1c1;
        private System.Windows.Forms.CheckBox q1c2;
        private System.Windows.Forms.CheckBox q1c3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox q2c1;
        private System.Windows.Forms.CheckBox q2c2;
        private System.Windows.Forms.CheckBox q2c3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox q3c1;
        private System.Windows.Forms.CheckBox q3c2;
        private System.Windows.Forms.CheckBox q3c3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.CheckBox q4c1;
        private System.Windows.Forms.CheckBox q4c2;
        private System.Windows.Forms.CheckBox q4c3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox q5c1;
        private System.Windows.Forms.CheckBox q5c2;
        private System.Windows.Forms.CheckBox q5c3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox q6c1;
        private System.Windows.Forms.CheckBox q6c2;
        private System.Windows.Forms.CheckBox q6c3;
        private System.Windows.Forms.CheckBox q7c1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox q7c2;
        private System.Windows.Forms.CheckBox q7c3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.CheckBox q8c1;
        private System.Windows.Forms.CheckBox q8c2;
        private System.Windows.Forms.CheckBox q8c3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox q9c1;
        private System.Windows.Forms.CheckBox q9c2;
        private System.Windows.Forms.CheckBox q9c3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox q10c1;
        private System.Windows.Forms.CheckBox q10c2;
        private System.Windows.Forms.CheckBox q10c3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox q11c1;
        private System.Windows.Forms.CheckBox q11c2;
        private System.Windows.Forms.CheckBox q11c3;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox q12c1;
        private System.Windows.Forms.CheckBox q13c1;
        private System.Windows.Forms.CheckBox q12c2;
        private System.Windows.Forms.CheckBox q13c2;
        private System.Windows.Forms.CheckBox q12c3;
        private System.Windows.Forms.CheckBox q13c3;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox q14c1;
        private System.Windows.Forms.CheckBox q14c2;
        private System.Windows.Forms.CheckBox q14c3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox q15c1;
        private System.Windows.Forms.CheckBox q15c2;
        private System.Windows.Forms.CheckBox q15c3;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox q16c1;
        private System.Windows.Forms.CheckBox q16c2;
        private System.Windows.Forms.CheckBox q16c3;
        private System.Windows.Forms.Button button16;
    }
}

